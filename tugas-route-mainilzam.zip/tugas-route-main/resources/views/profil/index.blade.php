@extends('welcome')

@section('content')
<h1>Profil Saya</h1>
<figure class="figure">
  <img
    src="{{ asset('test/img/ilzam.jpg') }}"
    height="400"
    alt="..."
  />
  <figcaption class="figure-caption">ilzam muhikam<br>
  XII RPL1/14<br>
  SMKN 1 Purwosari</figcaption>
</figure>
@endsection